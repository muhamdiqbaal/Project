<?php $__env->startSection('title'); ?>
    Welcome to E-Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.inc.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <h2>Featured Product</h2>
            <div class="owl-carousel featured-carousel owl-theme">
                <?php $__currentLoopData = $featured_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="card">
                            <img src="<?php echo e(asset('assets/uploads/products/'.$prod->image)); ?>" alt="Product image">
                            <div class="card-body">
                                <h5><?php echo e($prod->name); ?></h5>
                                <span class="float-start"><?php echo e($prod->selling_price); ?></span>
                                <span class="float-end"> <s> <?php echo e($prod->original_price); ?> </s> </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>





            <div class="py-5">
                <div class="container">
                    <div class="row">
                        <h2>Trending Kategori</h2>
                    <div class="owl-carousel featured-carousel owl-theme">
                        <?php $__currentLoopData = $trending_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="card">
                                    <img src="<?php echo e(asset('assets/uploads/category/'.$prod->image)); ?>" alt="Product image">
                                    <div class="card-body">
                                        <h5><?php echo e($category->name); ?></h5>
                                        <p>
                                            <?php echo e($category->description); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
        </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $('.featured-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Iqbal's Project\ecommerce\resources\views/frontend/index.blade.php ENDPATH**/ ?>