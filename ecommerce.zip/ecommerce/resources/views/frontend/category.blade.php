@extends('layouts.front')

@section('title')
    Category
@endsection

@section('content')
    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Semua Kategori</h2>
                    <div class="row">
                    @foreach ($category as $cate)
                        <div class="col-md-3 mb-3">
                            <a href="{{ url('view-category/'.$cate->slug) }}">
                                <img src="{{ asset('assets/uploads/category/'.$cate->image) }}" alt="Category image">
                                <div class="card-body">
                                    <h5>{{ $cate->name }}</h5>
                                    <p>
                                        {{ $cate->description }}
                                    </p>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
